# the published engine
import json, sys

for line in sys.stdin:
    try:
        message = json.loads(line)
    except ValueError:
        continue
    reply = {"jsonrpc": "2.0", "id": message.get("id")}
    if message.get("method") == "initialize":
        reply["result"] = {
            "protocol": "yarngo-engine", "version": 1,
            "backend": "fixture", "conditioning_eviction": "none",
            "methods": ["ping"],
        }
    else:
        reply["result"] = {}
    print(json.dumps(reply), flush=True)
    if message.get("method") == "shutdown":
        break
